# NovaCare — Hospital Visitor Management (HTML, CSS & JavaScript only)

## Technology
- HTML for pages
- CSS for styling and responsive layout
- Vanilla JavaScript for application logic
- IndexedDB (built into the browser) for persistent local data storage

No Node.js, Express, Python, frameworks, or external database server is used.

## Pages
- `index.html` — simple staff entry
- `dashboard.html` — visitor statistics and latest activity
- `register.html` — register visitors and record check-in time
- `records.html` — search, filter, check out, and delete visitor records

## Run
Open `index.html` in a modern browser, or use VS Code's Live Server extension to serve the folder. No package installation or build step is required.

## Persistence
Visitor data is saved in IndexedDB in the current browser and remains after refresh and browser restart. It is not synced to other devices. Clearing browser site data can remove it. This is suitable as a frontend-only academic demo, not as a production hospital system handling real patient information.

## GitHub / Deployment
This static project can be hosted on GitHub Pages, Netlify, or Vercel static hosting. Because it has no server, the data remains local to each visitor's browser and is not shared with hospital staff on other devices.
